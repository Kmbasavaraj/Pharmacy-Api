package com.example.pharma.adminexceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.pharma.exception.AdminNotFoundByIdException;
import com.example.pharma.util.AppResponseBuilder;
import com.example.pharma.util.ErrorStructure;

@RestControllerAdvice
public class AdminExceptionHandler {
	private final AppResponseBuilder errorBuilder;

	public AdminExceptionHandler(AppResponseBuilder errorBuilder) {
		super();
		this.errorBuilder = errorBuilder;
	}
	
	@ExceptionHandler(AdminNotFoundByIdException.class)
	public ResponseEntity<ErrorStructure<String>> handleAdminNotFoundById(AdminNotFoundByIdException ex){
		return errorBuilder.error(HttpStatus.NOT_FOUND, ex.getMessage(), "Admin Not Found By Requested Id in The Database");
	}

}
