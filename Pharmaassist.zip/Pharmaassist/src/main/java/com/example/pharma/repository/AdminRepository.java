package com.example.pharma.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pharma.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, String>{

}
