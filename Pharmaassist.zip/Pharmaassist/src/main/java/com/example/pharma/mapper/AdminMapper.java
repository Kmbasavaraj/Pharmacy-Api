package com.example.pharma.mapper;

import org.springframework.stereotype.Component;

import com.example.pharma.entity.Admin;
import com.example.pharma.requestdtos.AdminRequest;
import com.example.pharma.responsedtos.AdminResponse;

@Component
public class AdminMapper {
	
	public Admin mapToAdmin(AdminRequest adminRequest,Admin admin) {
		admin.setEmail(adminRequest.getEmail());
		admin.setPhoneNumber(adminRequest.getPhoneNumber());
		admin.setPassword(adminRequest.getPassword());
		
		return admin;
	}
	
	public AdminResponse mapToAdminResponse(Admin admin) {
		AdminResponse response = new AdminResponse();
		response.setEmail(admin.getEmail());
		response.setPhoneNumber(admin.getPhoneNumber());
		
		return response;
	}

}
