package com.example.pharma.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.pharma.entity.Admin;
import com.example.pharma.exception.AdminNotFoundByIdException;
import com.example.pharma.mapper.AdminMapper;
import com.example.pharma.repository.AdminRepository;
import com.example.pharma.requestdtos.AdminRequest;
import com.example.pharma.responsedtos.AdminResponse;

@Service
public class AdminService {
	private final AdminRepository adminRepository;
	private final AdminMapper adminMapper;

	public AdminService(AdminRepository adminRepository,AdminMapper adminMapper) {
		super();
		this.adminRepository = adminRepository;
		this.adminMapper = adminMapper;
	}
	
	public AdminResponse addAdmin(AdminRequest adminRequest) {
		Admin admin = adminRepository.save(adminMapper.mapToAdmin(adminRequest, new Admin()));
		return adminMapper.mapToAdminResponse(admin);
	}

	public AdminResponse findAdminById(String adminId) {
		return adminRepository.findById(adminId)
				.map(adminMapper::mapToAdminResponse)
				.orElseThrow(()->new AdminNotFoundByIdException("Admin Not Found"));
	}
	
	public List<AdminResponse> findAll(){
		return adminRepository.findAll()
				.stream()
				.map(adminMapper::mapToAdminResponse)
				.toList();
	}
	
	public AdminResponse updateAdminById(AdminRequest adminRequest, String adminId) {
		return adminRepository.findById(adminId)
				.map(exAdmin->{
					adminMapper.mapToAdmin(adminRequest, exAdmin);
					return adminRepository.save(exAdmin);
				})
				.map(adminMapper::mapToAdminResponse)
				.orElseThrow(()->new AdminNotFoundByIdException("Admin not Found To Update"));
	}
	
}
