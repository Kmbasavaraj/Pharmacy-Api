package com.example.pharma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmaassistApplication {

	public static void main(String[] args) {
		SpringApplication.run(PharmaassistApplication.class, args);
	}

}
